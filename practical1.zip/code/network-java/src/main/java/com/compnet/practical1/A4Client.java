
package com.compnet.practical1;

/**
 *
 * @author TODO
 */
public class A4Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
