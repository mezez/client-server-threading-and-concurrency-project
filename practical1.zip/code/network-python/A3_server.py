
from threading import Thread
import socket
import display
from netutils import read_line
import random

def main(): # called at the end of the file
    d = display.Display()
    # start a new thread to accept new connections
    handle_acceptall().start()


def handle_acceptall():
    def handle():
        # create a socket that listens (on a port of your choice)
        server_socket = ???
        # accept new clients connections,
        # and start a handle_client thread every time
        ???

    t = Thread(target=handle)
    return t


# handle_client returns a Thread that can be started, i.e., use: handle_client(.......).start()
def handle_client(socket):
    def handle():
        # initialise a random integer position, e.g. between 0 and 100
        i = ???

        # initialize a random direction (for later)
        by = random.choice([-1, 1])

        # add 1 to the display, at index i (and render it)
        ???

        # loop over the received data, ignoring (or just printing) this data for now (e.g., use netutils to read lines)
        # be sure to end the loop when the connection is closed (readLine returns None or throws an exception)
        ???

        # Later, we will use move_value_right(i, by) and increase the i variable by
        # ???

        # when the connection is closed, subtract at index (and rerender)
        ???

    t = Thread(target=handle)
    return t


if __name__== "__main__":
  main()
